import 'bootstrap/js/src/collapse'  
import 'bootstrap/js/src/dropdown' 
import 'bootstrap/js/src/scrollspy'
