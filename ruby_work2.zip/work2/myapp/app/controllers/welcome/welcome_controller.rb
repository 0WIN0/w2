class WelcomeController < ApplicationController  
end  